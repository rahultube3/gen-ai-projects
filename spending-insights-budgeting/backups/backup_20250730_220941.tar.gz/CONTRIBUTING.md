# Contributing to Advanced Spending Insights & Budgeting

Thank you for your interest in contributing to this project! 🎉

## 🚀 Getting Started

### Prerequisites
- Python 3.10+
- [uv](https://github.com/astral-sh/uv) package manager (recommended)
- OpenAI API key for testing AI features

### Development Setup

1. **Fork and clone the repository**
```bash
git clone https://github.com/your-username/gen-ai-projects.git
cd gen-ai-projects/spending-insights-budgeting
```

2. **Set up development environment**
```bash
uv sync --dev
cp .env.example .env
# Add your OpenAI API key to .env
```

3. **Initialize the database**
```bash
uv run python db_setup.py
```

4. **Run tests**
```bash
uv run pytest
```

## 📝 Development Guidelines

### Code Style
- Follow PEP 8 style guidelines
- Use type hints where appropriate
- Keep functions focused and well-documented
- Maximum line length: 100 characters

### Code Formatting
```bash
# Format code
uv run black .

# Check linting
uv run ruff check .

# Fix auto-fixable issues
uv run ruff check --fix .
```

### Commit Messages
Use conventional commit format:
```
feat: add new budget optimization algorithm
fix: resolve NameError in financial health score calculation
docs: update API documentation
test: add tests for vectorstore caching
refactor: optimize database query performance
```

## 🧪 Testing

### Running Tests
```bash
# Run all tests
uv run pytest

# Run with coverage
uv run pytest --cov=.

# Run specific test file
uv run pytest tests/test_vectorstore.py
```

### Test Guidelines
- Write tests for new features
- Maintain test coverage above 80%
- Use descriptive test names
- Mock external API calls (OpenAI)

## 🐛 Bug Reports

When reporting bugs, please include:

1. **Environment details**
   - Python version
   - Operating system
   - Package versions (`uv tree`)

2. **Steps to reproduce**
   - Minimal code example
   - Expected vs actual behavior
   - Error messages/logs

3. **Additional context**
   - Screenshots (for UI issues)
   - Performance impact
   - Workarounds found

## ✨ Feature Requests

For new features, please provide:

1. **Use case description**
   - Who would benefit?
   - What problem does it solve?

2. **Proposed solution**
   - High-level implementation approach
   - API design (if applicable)

3. **Alternatives considered**
   - Other approaches evaluated
   - Why this solution is preferred

## 🚀 Pull Request Process

### Before Submitting
- [ ] Tests pass locally
- [ ] Code is formatted and linted
- [ ] Documentation is updated
- [ ] CHANGELOG.md is updated (if applicable)

### PR Guidelines
1. **Create a feature branch**
```bash
git checkout -b feature/your-feature-name
```

2. **Make your changes**
   - Keep commits atomic and focused  
   - Write clear commit messages
   - Update documentation

3. **Test thoroughly**
```bash
uv run pytest
uv run python streamlit_app.py  # Manual testing
```

4. **Submit pull request**
   - Use descriptive PR title
   - Fill out PR template completely
   - Link to related issues

### PR Review Process
- Code review by maintainers
- Automated testing via CI/CD
- Documentation review
- Security and privacy review (for sensitive features)

## 🏗️ Project Architecture

### Key Components
- **`streamlit_app.py`** - Main dashboard interface
- **`vectorstore.py`** - RAG and semantic search
- **`db_setup.py`** - Database initialization
- **`redact.py`** - Privacy protection system

### Adding New Features

#### New Dashboard Tab
1. Add tab creation in `main()` function
2. Create tab display function
3. Add any required database schema changes
4. Update tests and documentation

#### New AI Feature
1. Extend vectorstore functionality in `vectorstore.py`
2. Add new query types in AI assistant
3. Update embedding and search logic
4. Test with various query types

#### New Visualization
1. Create chart function using Plotly
2. Add to appropriate dashboard tab
3. Ensure responsive design
4. Test with different data sizes

## 🔒 Security & Privacy

### Privacy Guidelines
- Never log sensitive financial data
- Use appropriate redaction levels
- Test redaction functionality thoroughly
- Document privacy implications

### Security Considerations
- Validate all user inputs
- Sanitize database queries
- Secure API key handling
- Review dependencies for vulnerabilities

## 📚 Documentation

### Code Documentation
- Use docstrings for all functions/classes
- Include parameter types and descriptions
- Provide usage examples
- Document complex algorithms

### User Documentation
- Update README.md for new features
- Add configuration examples
- Include troubleshooting steps
- Provide performance benchmarks

## 🤝 Community

### Communication Channels
- **GitHub Issues** - Bug reports and feature requests
- **GitHub Discussions** - General questions and ideas
- **Pull Request Reviews** - Code discussion

### Code of Conduct
- Be respectful and inclusive
- Focus on constructive feedback
- Help newcomers get started
- Follow project guidelines

## 📋 Release Process

### Version Numbering
We follow [Semantic Versioning](https://semver.org/):
- **MAJOR** - Breaking changes
- **MINOR** - New features (backward compatible)
- **PATCH** - Bug fixes

### Release Checklist
- [ ] Update version in `pyproject.toml`
- [ ] Update CHANGELOG.md
- [ ] Tag release in git
- [ ] Test full installation flow
- [ ] Update documentation

## 🙏 Recognition

Contributors will be recognized in:
- README.md contributors section
- Release notes
- Git commit history

## 📞 Getting Help

If you need help contributing:
- Check existing issues and discussions
- Ask questions in GitHub Discussions
- Review the project documentation
- Contact maintainers via email

---

Thank you for contributing to make financial analytics more accessible and powerful! 🚀
